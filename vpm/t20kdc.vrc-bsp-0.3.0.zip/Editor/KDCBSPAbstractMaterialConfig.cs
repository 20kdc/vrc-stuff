using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.AssetImporters;

namespace KDCVRCBSP {
	/**
	 * KDCBSPAbstractMaterialConfig defines things materials care about.
	 */
	public abstract class KDCBSPAbstractMaterialConfig : ScriptableObject {
		/// Not much to this one; if true, it's included in collision by default.
		[Tooltip("Enables/disables collision. This only works on convexes if it wins priority, but it always works on concave root.")]
		[SerializeField]
		public bool collisionEnable = true;

		/// Setup in KDCBSPImporter.SetupBrushRenderer
		[Tooltip("Multiplier for lightmap scale for this material. If zero, this does NOT turn off ContributeGI, just lightmap generation.")]
		[SerializeField]
		public float lightmapScaleMul = 1.0f;

		/// Setup in KDCBSPImporter.CreateEntity
		/// Sets the physics material.
		/// By the way, this has to be changed to PhysicsMaterial when Unity updates. For some reason.
		[Tooltip("Sets the physics material. This only works on convexes if it wins priority, and never works on concave root.")]
		[SerializeField]
		public LazyLoadReference<PhysicMaterial> collisionMaterial;

		/// Builds a material's 'visual'. This is a GameObject, which is returned.
		/// If the importer wishes to override static flags, that's done after BuildVisualObject.
		/// 'data' may be modified as you wish.
		/// A key note: If LightProbeUsage or ReflectionProbeUsage is set to off here, they *stay* off.
		/// This allows the renderer to indicate it doesn't use these features, as an optimization.
		public abstract GameObject BuildVisualObject(KDCBSPImportContext ctx, string materialName, string meshAssetName, List<KDCBSPIntermediate.TriInfo> data, GameObject visualsGO, KDCBSPBrushEntitySettings brushEntitySettings);

		/// Calculates the collision convex priority for a given normal.
		/// This is used when deciding which material config to use for physics materials/etc.
		/// Note that this mechanism is not in use for the concave root mode.
		public abstract float GetCollisionConvexPriority(Vector3 normal);

		/// Contributes ericw-tools and TrenchBroom metadata to the PAK.
		/// Importantly, discoveryPath accounts for the situation where a material config is created on behalf of a material file.
		/// Note that because this logic is 'pretty universal', even for really 'unusual' materials, it's implemented here.
		public virtual void PAKContribute(SortedDictionary<string, byte[]> pakFiles, string materialPath, string discoveryPath) {
			var tex = PAKGetTrenchBroomTexture(materialPath, discoveryPath);
			if (tex == null) {
				Debug.LogWarning("NO ICON: " + PAKGetTrenchBroomTextureOverridePath(discoveryPath));
				tex = KDCBSPUtilities.ReadLPImageOrNull(KDCBSPUtilities.KVBSP_BASE + "Editor/Icons/noIcon.png");
			}
			pakFiles["textures/" + materialPath + ".png"] = tex.EncodeToPNG();
			var walJSON = PAKGetWALJSON(materialPath, discoveryPath);
			if (walJSON != null)
				pakFiles["textures/" + materialPath + ".wal_json"] = walJSON;
		}

		public string PAKGetTrenchBroomTextureOverridePath(string discoveryPath) {
			return Path.Join(Path.GetDirectoryName(discoveryPath), Path.GetFileNameWithoutExtension(discoveryPath) + ".png");
		}

		/// Gets the 'override' icon, if any.
		/// You SHOULD use this in PAKGetTrenchBroomTexture.
		public Texture2D PAKGetTrenchBroomTextureOverride(string discoveryPath) {
			string hypothesis = PAKGetTrenchBroomTextureOverridePath(discoveryPath);
			return KDCBSPUtilities.ReadLPImageOrNull(hypothesis);
		}

		/// Gets the texture as shown in TrenchBroom. Here, one Quake unit == 1 pixel.
		/// Note that this can return null. In that event, a default is loaded and used.
		public virtual Texture2D PAKGetTrenchBroomTexture(string materialPath, string discoveryPath) {
			return PAKGetTrenchBroomTextureOverride(discoveryPath);
		}

		/// Gets the .wal_json file contents.
		/// If null, no such file is made.
		public virtual byte[] PAKGetWALJSON(string materialPath, string discoveryPath) {
			string hypothesis = Path.Join(Path.GetDirectoryName(discoveryPath), Path.GetFileNameWithoutExtension(discoveryPath) + ".wal_json");
			return KDCBSPUtilities.ReadLPBytesOrNull(hypothesis);
		}

		public abstract class Simple : KDCBSPAbstractMaterialConfig {
			/// Base priority for determining which material a brush is made of. The normal Y (-1 to 1) is added to this, to bias in favour of floors by default.
			public abstract float BaseCollisionConvexPriority { get; }

			/// Implements retrieving the material information.
			public abstract SimpleMaterialInfo GetMaterial(KDCBSPImportContext ctx, string materialName, string meshAssetName);

			public override GameObject BuildVisualObject(KDCBSPImportContext ctx, string materialName, string meshAssetName, List<KDCBSPIntermediate.TriInfo> data, GameObject visualsGO, KDCBSPBrushEntitySettings brushEntitySettings) {

				var mInfo = GetMaterial(ctx, materialName, meshAssetName);

				if (mInfo.material == null)
					return null;

				GameObject materialGO;

				if (brushEntitySettings.rendererTemplate.isSet) {
					materialGO = (GameObject) UnityEngine.Object.Instantiate(brushEntitySettings.rendererTemplate.asset, Vector3.zero, Quaternion.identity, visualsGO.transform);
					materialGO.name = materialName;
				} else {
					materialGO = new GameObject(materialName);
					materialGO.transform.parent = visualsGO.transform;
				}

				var uvMul = Vector2.one / mInfo.size;
				// This
				if ((!float.IsFinite(uvMul.x)) || (!float.IsFinite(uvMul.y))) {
					Debug.LogWarning($"Fixing non-finite uvMul in material {materialName} mesh asset {meshAssetName} to prevent lightmapper freeze.\nPlease setup a KDCBSPMaterialConfig with an explicit size!");
					uvMul = Vector2.one;
				}
				Mesh mesh = KDCBSPIntermediate.TrianglesToMesh(data, uvMul);

				Unwrapping.GenerateSecondaryUVSet(mesh, KDCBSPImporter.BrushEntitySettingsToUnwrapParam(brushEntitySettings));

				ctx.assetImportContext.AddObjectToAsset(meshAssetName, mesh);

				var meshFilter = materialGO.GetComponent<MeshFilter>();
				if (meshFilter == null)
					meshFilter = materialGO.AddComponent<MeshFilter>();

				var meshRender = materialGO.GetComponent<MeshRenderer>();
				if (meshRender == null)
					meshRender = materialGO.AddComponent<MeshRenderer>();

				var materialsList = new List<Material>();
				materialsList.Add(mInfo.material);
				meshRender.SetSharedMaterials(materialsList);

				// mesh.isReadable = false;
				mesh.UploadMeshData(true);
				meshFilter.mesh = mesh;

				meshRender.receiveShadows = mInfo.receiveShadows;
				meshRender.shadowCastingMode = mInfo.shadowCastingMode;
				if (mInfo.optForceDisableLightProbes)
					meshRender.lightProbeUsage = UnityEngine.Rendering.LightProbeUsage.Off;
				if (mInfo.optForceDisableReflectionProbes)
					meshRender.reflectionProbeUsage = UnityEngine.Rendering.ReflectionProbeUsage.Off;

				return materialGO;
			}

			public override float GetCollisionConvexPriority(Vector3 normal) {
				return BaseCollisionConvexPriority + normal.y;
			}

			public virtual SimpleIconInfo PAKGetTrenchBroomTextureSimple(string materialPath, string discoveryPath) {
				return new SimpleIconInfo {
					source = null,
					offset = Vector2.zero,
					scale = Vector2.zero,
					iconSize = Vector2.zero
				};
			}

			public override Texture2D PAKGetTrenchBroomTexture(string materialPath, string discoveryPath) {
				var ovr = PAKGetTrenchBroomTextureOverride(discoveryPath);
				if (ovr != null)
					return ovr;

				var iconInfo = PAKGetTrenchBroomTextureSimple(materialPath, discoveryPath);
				if (iconInfo.source == null)
					return base.PAKGetTrenchBroomTexture(materialPath, discoveryPath);
				int width = (int) iconInfo.iconSize.x;
				if (width < 1)
					width = 1;
				int height = (int) iconInfo.iconSize.y;
				if (height < 1)
					height = 1;
				var rt = new RenderTexture(width, height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
				Graphics.Blit(iconInfo.source, rt, iconInfo.scale, iconInfo.offset);
				return KDCBSPUtilities.ReadRenderTexture(rt);
			}

			public struct SimpleMaterialInfo {
				public Material material;
				public Vector2 size;
				public bool receiveShadows;
				public UnityEngine.Rendering.ShadowCastingMode shadowCastingMode;
				public bool optForceDisableLightProbes, optForceDisableReflectionProbes;
			}

			/// Icon information.
			/// This represents a possible MainTex.
			/// If source is null, this is invalid.
			public struct SimpleIconInfo {
				public Texture source;
				public Vector2 offset;
				public Vector2 scale;
				/// Should match SimpleMaterialInfo.size
				public Vector2 iconSize;
			}
		}
	}
}
