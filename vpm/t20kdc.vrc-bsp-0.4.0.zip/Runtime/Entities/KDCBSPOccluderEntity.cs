using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using KDCVRCBSP.ECL;

namespace KDCVRCBSP {
	/**
	 * Entity parameterizer for func_occluder.
	 */
	public class KDCBSPOccluderEntity : KDCBSPEntity {
		public override void EntityCompile(IKDCBSPImportContext importContext, ECLBSPFile.Entity entity, string uniqueName) {
			// don't bother calling base
			bool open = entity.GetBool("open", false);
			var portal = GetComponent<OcclusionPortal>();
			portal.open = open;
			KDCBSPUtilities.GetEntityBox(entity, importContext.WorldScale, out Vector3 centre, out Vector3 size);
#if UNITY_EDITOR
			// this is so stupid!
			using (var so = new UnityEditor.SerializedObject(portal)) {
				so.Update();
				so.FindProperty("m_Center").vector3Value = centre;
				so.FindProperty("m_Size").vector3Value = size;
				so.ApplyModifiedProperties();
			}
#endif
		}
		public override KDCBSPBrushEntitySettings EntityGetBrushSettings(bool isWorldspawn, KDCBSPBrushEntitySettings prev) {
			return new KDCBSPBrushEntitySettings {
				visuals = false,
				collision = KDCBSPBrushEntitySettings.CollisionMode.None
			};
		}
	}
}
